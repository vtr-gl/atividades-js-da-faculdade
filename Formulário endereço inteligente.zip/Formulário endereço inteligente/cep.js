// Selecionando elementos
const inputCEP = document.getElementById("cepField");
const inputLog = document.getElementById("street");
const inputBairro = document.getElementById("neighborhood");
const inputCidade = document.getElementById("city");
const inputUF = document.getElementById("state");
const btnLocalizar = document.getElementById("btnLocalizar");
const feedbackDiv = document.getElementById("feedback");

// Função para mostrar mensagens
function mostrarFeedback(msg, isErro = true) {
    feedbackDiv.textContent = msg;
    feedbackDiv.style.color = isErro ? "#d32f2f" : "#388e3c";
}

// Limpar campos de endereço
function limparEndereco() {
    inputLog.value = "";
    inputBairro.value = "";
    inputCidade.value = "";
    inputUF.value = "";
    feedbackDiv.textContent = "";
}

// Formatar CEP enquanto digita
inputCEP.addEventListener("input", () => {
    let cep = inputCEP.value.replace(/\D/g, "");
    if (cep.length > 5) cep = cep.replace(/^(\d{5})(\d{1,3})$/, "$1-$2");
    inputCEP.value = cep;
});

// Função principal para buscar CEP
async function localizarCEP() {
    limparEndereco();
    const cep = inputCEP.value.replace(/\D/g, "");

    if (cep.length !== 8) {
        mostrarFeedback("CEP inválido. Deve conter 8 números.");
        return;
    }

    try {
        mostrarFeedback("Consultando CEP...", false);
        const response = await fetch(`https://viacep.com.br/ws/${cep}/json/`);
        const data = await response.json();

        if (data.erro) {
            mostrarFeedback(`CEP não encontrado: ${inputCEP.value}`);
            limparEndereco();
        } else {
            inputLog.value = data.logradouro || "";
            inputBairro.value = data.bairro || "";
            inputCidade.value = data.localidade || "";
            inputUF.value = data.uf || "";
            mostrarFeedback("Endereço localizado com sucesso!", false);
        }
    } catch (error) {
        console.error("Erro ao consultar o CEP:", error);
        mostrarFeedback("Falha ao consultar CEP. Tente novamente.");
    }
}

// Eventos
btnLocalizar.addEventListener("click", localizarCEP);
inputCEP.addEventListener("keypress", e => {
    if (e.key === "Enter") {
        e.preventDefault();
        localizarCEP();
    }
});
inputCEP.addEventListener("blur", localizarCEP);
